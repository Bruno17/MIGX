<?php
$xpdo_meta_map = array (
    'version' => '3.0',
    'namespace' => 'Migx\\Model',
    'namespacePrefix' => 'Migx',
    'class_map' => 
    array (
        'xPDO\\Om\\xPDOSimpleObject' => 
        array (
            0 => 'Migx\\Model\\migxConfig',
            1 => 'Migx\\Model\\migxFormtab',
            2 => 'Migx\\Model\\migxFormtabField',
            3 => 'Migx\\Model\\migxConfigElement',
            4 => 'Migx\\Model\\migxElement',
        ),
    ),
);