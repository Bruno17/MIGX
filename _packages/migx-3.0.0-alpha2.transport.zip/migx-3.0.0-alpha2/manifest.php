<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '# MIGX

Multi-Items-Grid for MODX-Revolution.

## What is MIGX

MIGX is a <a href="https://rtfm.modx.com/revolution/2.x/making-sites-with-modx/customizing-content/template-variables/adding-a-custom-tv-input-type" title="Adding a Custom TV Input Type">custom</a> <a href="https://rtfm.modx.com/revolution/2.x/making-sites-with-modx/customizing-content/template-variables" title="Template Variables">Template Variable</a> (TV) input type for aggregating multiple TVs into one TV. This aggregation greatly simplifies the workflow for end users of the manager to add complex data items to the manager. A data item can consist of any number of any other TVs, including text, images, files, checkboxes, etc.

The package is highly customizable and allows the developer to define a custom input window for the MIGX TV. From this input window, items can be added, modified, and reordered.

The package also ships with a snippet (<a href="/extras/revo/migx/migx.frontend-usage" title="MIGX.Frontend-Usage">getImageList</a>) that facilitates the easy retrieval of the complex data items from the custom MIGX TV input type.

## MIGXdb

While MIGX stores its items all in one field as a json-string, MIGXdb handles records of custom-tables.
With a MIGXdb-TV, you can handle resource-related-records of a custom-table or even child-resources of the currently edited resource.

Its also very easy to create CMPs (Custom Manager Pages) to manage your custom-tables with help of MIGXdb.

There is also a snippet (migxLoopCollection) to show records of custom-tables at the frontend. 
',
    'requires' => 
    array (
      'modx' => '>=3.0.0-alpha',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '366a1185010df478282091352d4e6e23',
      'native_key' => 'migx',
      'filename' => 'MODX/Revolution/modNamespace/2d05071beefffe1bf2fdaaabfbf010ab.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'accb88c838648fa2db63680c1246de63',
      'native_key' => 'accb88c838648fa2db63680c1246de63',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/7d4e4c3c9d0dab00a1befcb6668d3963.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '9bc1bacedc363a9a6e13b43985a930cd',
      'native_key' => '9bc1bacedc363a9a6e13b43985a930cd',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/30f6409295ddaea44769b26fe7a8db6f.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => 'd1d3dc535aa03babea1ff0fa516f1c98',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/a4106f39f01bfab6c682667ec8a7df1d.vehicle',
    ),
  ),
);