<?php
class migxElement extends xPDOSimpleObject {}