<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'b6be0774491e4716b22f3d8aadbc22f8',
      'native_key' => 'migx',
      'filename' => 'modNamespace/9d27f77c9d2cb078e782956772c38fdf.vehicle',
      'namespace' => 'migx',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '2f6a6d76b7cbedb24466cb3cf2431a45',
      'native_key' => 1,
      'filename' => 'modPlugin/d3d63692f63a2138376a7072fdbf737d.vehicle',
      'namespace' => 'migx',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '5523593d98d2c3f8ac342f6f649ae217',
      'native_key' => 1,
      'filename' => 'modCategory/cd84b566a0bea782cfc3d88db81ae2a3.vehicle',
      'namespace' => 'migx',
    ),
  ),
);