<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'e4650d07d15d4f0d16443ba1184894a4',
      'native_key' => 'migx',
      'filename' => 'modNamespace/b92ba14f62bd69ba56b0d369d965ec7c.vehicle',
      'namespace' => 'migx',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '406dcd1df99c20d566c31af0cbe5c93b',
      'native_key' => 3,
      'filename' => 'modPlugin/922fdce43ce57b019fdf5c37ff305912.vehicle',
      'namespace' => 'migx',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '13405b918e26900d4eb23fb8d57f8a40',
      'native_key' => 1,
      'filename' => 'modCategory/da4266fc02b5c96799573e43b28748b1.vehicle',
      'namespace' => 'migx',
    ),
  ),
);