<?php

/**

 * migx

 *

 * @package migx

 * @language it

 */

//$_lang['mig_'] = '';

$_lang['mig_noitems'] = 'Nessun elemento trovato';
$_lang['mig_add'] = 'Aggiungi Elemento';
$_lang['mig_remove_confirm'] = 'Rimuovere Elemento?';
$_lang['mig_edit'] = 'Modifica';
$_lang['mig_remove'] = 'Rimuovi';
$_lang['mig_duplicate'] = 'Duplica';
$_lang['mig_preview'] = 'Preview';