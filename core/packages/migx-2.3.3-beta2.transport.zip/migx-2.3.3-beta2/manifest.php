<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '40b07212ff6e6860c5ff18914d438ded',
      'native_key' => 'migx',
      'filename' => 'modNamespace/092dac76d4d4b2c1da0313ccb502061e.vehicle',
      'namespace' => 'migx',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'd2e30c7da040438e8b2b6e7019129fe8',
      'native_key' => 1,
      'filename' => 'modPlugin/88aa89792e035403fc593c7770b5a34f.vehicle',
      'namespace' => 'migx',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '3a929c745a54f914a9b915fa54ceb405',
      'native_key' => 1,
      'filename' => 'modCategory/a4894ab53c1a0619ae5a795f69c57979.vehicle',
      'namespace' => 'migx',
    ),
  ),
);