<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'ce67e5f40704bb2635d3b58f4d972ccc',
      'native_key' => 'migx',
      'filename' => 'modNamespace/6c9b50975c8c4516f7243923ff73cecc.vehicle',
      'namespace' => 'migx',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'cdccceac483f6147a87572ae77ef0378',
      'native_key' => 3,
      'filename' => 'modPlugin/7bf8580314857dbc4bf6e8ada892cc53.vehicle',
      'namespace' => 'migx',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '98c64aa884260a723c6fe521dc8b24fc',
      'native_key' => 1,
      'filename' => 'modCategory/cb40d8d291e111ae708f645621881eda.vehicle',
      'namespace' => 'migx',
    ),
  ),
);