<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'beb7010cbd6f0e7c56e3cc6bcde372bc',
      'native_key' => 'multiitemsgridTv',
      'filename' => 'modNamespace/f31315e12a6acce057f60f74e494c7e1.vehicle',
      'namespace' => 'multiitemsgridTv',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'e4a8904759e15bc84134f65ac16f4860',
      'native_key' => 3,
      'filename' => 'modPlugin/08e91bf098dc5f66165059661e53d0a3.vehicle',
      'namespace' => 'multiitemsgridTv',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'a8746acbb11342f99a102df955daa209',
      'native_key' => 1,
      'filename' => 'modCategory/57530e8a0c44860a68849a5a0ed0aa4d.vehicle',
      'namespace' => 'multiitemsgridTv',
    ),
  ),
);