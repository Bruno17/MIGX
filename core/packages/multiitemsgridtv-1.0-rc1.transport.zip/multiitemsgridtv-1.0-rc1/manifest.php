<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'a75f5911c9566bb7a6a200583d16da2e',
      'native_key' => 'multiitemsgridTv',
      'filename' => 'modNamespace/701907f9cb7c50ef6c8fea2f7d63f06a.vehicle',
      'namespace' => 'multiitemsgridTv',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'f33d925237a53a436b5d3fc06caa3747',
      'native_key' => 3,
      'filename' => 'modPlugin/57caba445b77bde7ccec76d6ff948629.vehicle',
      'namespace' => 'multiitemsgridTv',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '2b1bc7401dc17f8ed0ff6a94eca57383',
      'native_key' => 1,
      'filename' => 'modCategory/e23b99ee1ecb07b113a6677ef10637d8.vehicle',
      'namespace' => 'multiitemsgridTv',
    ),
  ),
);