<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '805c34b93f468ab147897cda59af1bc2',
      'native_key' => 'multiitemsgridTv',
      'filename' => 'modNamespace/f07ef63cc3323f636fdedaeddac23774.vehicle',
      'namespace' => 'multiitemsgridTv',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '26909b93386d022e7b3bc289cbb31dda',
      'native_key' => 3,
      'filename' => 'modPlugin/aac90c9ce1a52174ec181cee118b3a5b.vehicle',
      'namespace' => 'multiitemsgridTv',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '3339c61899e439c5a4850298e3af935b',
      'native_key' => 1,
      'filename' => 'modCategory/36c1aa7e19904c4bed7720b47c2e32e1.vehicle',
      'namespace' => 'multiitemsgridTv',
    ),
  ),
);