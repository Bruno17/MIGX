<?php
/**
 * MultiItemsGridTv
 *
 * @package multiitemsgridTv
 * @language en
 */


$_lang['mig.tabs'] = 'Form Tabs';
$_lang['mig.columns'] = 'Grid Columns';