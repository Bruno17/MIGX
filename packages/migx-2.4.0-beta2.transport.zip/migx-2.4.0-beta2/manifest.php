<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '9ac00342835e9bb2f04dca4529451b4d',
      'native_key' => 'migx',
      'filename' => 'modNamespace/38d472f91906949f39fc81f9a1075c53.vehicle',
      'namespace' => 'migx',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '46657f805dbc97c1e6205a10881218c8',
      'native_key' => 1,
      'filename' => 'modPlugin/2093e534f8defc9533627856a88554b3.vehicle',
      'namespace' => 'migx',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'd4daa5d631edce32d2b78e18b403c825',
      'native_key' => 1,
      'filename' => 'modCategory/3182652c7f244dedd0614800f1586e1e.vehicle',
      'namespace' => 'migx',
    ),
  ),
);