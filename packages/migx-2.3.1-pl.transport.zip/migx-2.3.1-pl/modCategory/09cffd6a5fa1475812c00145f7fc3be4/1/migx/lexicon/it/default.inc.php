<?php

/**

 * migx

 *

 * @package migx

 * @language it

 */

//$_lang['mig_'] = '';

$_lang['mig_noitems'] = 'Nessun elemento trovato';
$_lang['mig_add'] = 'Aggiungi elemento';
$_lang['mig_remove_confirm'] = 'Rimuovere elemento?';
$_lang['mig_edit'] = 'Modifica';
$_lang['mig_remove'] = 'Rimuovi';
$_lang['mig_duplicate'] = 'Duplica';
$_lang['mig_preview'] = 'Anteprima';
$_lang['mig_save_resource'] = 'Prima di aggiungere nuovi elementi, devi salvare questa risorsa!';
$_lang['mig_save_resource'] = 'Prima di aggiungere nuovi elementi, devi salvare questa risorsa!';

$_lang['mig_show_trash'] = 'Trash View';
$_lang['mig_show_normal'] = 'Normal View';
$_lang['migx.export_current_view'] = 'Export Current View';

$_lang['mig_loadgrid'] = 'load grid';