<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '87321c4c6dfc5875eb749defdd9408b9',
      'native_key' => 'migx',
      'filename' => 'modNamespace/07abfdf71c24fdb9d06d3895fe45dfce.vehicle',
      'namespace' => 'migx',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '2809ef49ff12cb2368cee13e4bba77b3',
      'native_key' => 1,
      'filename' => 'modPlugin/f3169018839a20a4ffef0b4210fc8dda.vehicle',
      'namespace' => 'migx',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '6cf2125ed7cb94c871e5a29e065c282b',
      'native_key' => 1,
      'filename' => 'modCategory/9a4fc9ba0cc16f0bb0a8f190de605cfb.vehicle',
      'namespace' => 'migx',
    ),
  ),
);