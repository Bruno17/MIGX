<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '72907e6de336ff53c73e9a907a008df4',
      'native_key' => 'migx',
      'filename' => 'modNamespace/932a6eac41618b59482fcc2d283134e4.vehicle',
      'namespace' => 'migx',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'c63b9682d9386bfb81b12a31f3ddf882',
      'native_key' => 1,
      'filename' => 'modPlugin/bf5830bfd8d084a00a33044e2c2fb3fe.vehicle',
      'namespace' => 'migx',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'e7ad1681f6754cef0123c6f98b1ddb0b',
      'native_key' => 1,
      'filename' => 'modCategory/318512aaa99dd652337dde178be9c740.vehicle',
      'namespace' => 'migx',
    ),
  ),
);