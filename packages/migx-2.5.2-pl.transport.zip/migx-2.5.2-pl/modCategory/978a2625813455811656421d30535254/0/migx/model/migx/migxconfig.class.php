<?php
class migxConfig extends xPDOSimpleObject {}