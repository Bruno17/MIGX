<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '214d8a135b45ddd32e0f8d0893172405',
      'native_key' => 'migx',
      'filename' => 'modNamespace/cc4acd5446302dcbdd32becce765bf2c.vehicle',
      'namespace' => 'migx',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '3c7fac68e7e00c8081a60b4757561764',
      'native_key' => 1,
      'filename' => 'modPlugin/d4e4d65b1ea204e4a179d6a50529e78f.vehicle',
      'namespace' => 'migx',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '63ea6bd31c92cbb4d2d376be55e04e19',
      'native_key' => 1,
      'filename' => 'modCategory/f2cd014a800e4c6752188809cbc62a71.vehicle',
      'namespace' => 'migx',
    ),
  ),
);